import React from 'react';
import AppView from './views/AppView';
 
function App () {
  return ( 
    <React.Fragment>
      <AppView />
    </React.Fragment>
 );
}
 
export default App;